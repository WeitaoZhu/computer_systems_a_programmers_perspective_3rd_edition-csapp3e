Programs that demonstrate the performance impact of cache memories

Makefile
        "make clean; make" to compile and build everything

matmult/ 
        Examples of different blocked and unblocked 2d matmult
        implementations

mountain/
        Code for the memory mountain

sumarray3d.c
sumarraycols.c
sumarrayrows.c
sumvec.c
        Examples of different matrix and vector sum routines
