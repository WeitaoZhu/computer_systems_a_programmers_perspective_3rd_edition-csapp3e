Example programs from the parallelism lecture
Makefile
        "make clean; make" to compile everything        

csapp.{c,h}
        CS:APP3e code library

pqsort/
        Parallel quicksort

psum-array.c
psum-local.c
psum-mutex.c
        Different implementation of parallel sum

psum.xlsx
        Performance of parallel sum

results/
        Results of parallel qicksort on different machines
