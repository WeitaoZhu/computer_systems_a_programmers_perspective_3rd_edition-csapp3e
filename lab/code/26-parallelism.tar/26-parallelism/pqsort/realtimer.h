/* Routines to compute elapsed wall time. */

/* Required for initialization */
void start_timer();

/* Number of seconds since call to start_timer() */
double elapsed_time();
