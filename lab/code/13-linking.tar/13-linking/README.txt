
EXTENSIONS
        .s: assembly code
        .d: dissassembled object file
        .o: relocatable object file
        .a: static library
        .so: shared library

FILES
Makefile
        "make clean; make" generates all files

main.c
sum.c
        Simple example program

main2.c
addvec.c
multvec.c
vector.h
        Example program for linking at compile time and load time

dll.c
        Example program for dynamic linking at run time

interpose/
        Interpositioning case study
