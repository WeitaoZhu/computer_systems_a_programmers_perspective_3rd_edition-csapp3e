Various programs used in the I/O lecture

cpfile.c
        Using the RIO routines to copy from stdin to stdout

csapp.{c,h}
        CS:APP wrappers

ffiles1.c
ffiles2.c
ffiles3.c
        File puzzles

hello.c
        Demonstrates buffering in libc function

statcheck.c
        stat example
