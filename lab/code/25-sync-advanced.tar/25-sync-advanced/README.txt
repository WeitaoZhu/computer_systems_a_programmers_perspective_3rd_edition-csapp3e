Examples from the second synchronization lecture

Makefile
        "make clean; make" to compile everything
csapp.{c,h}
        CS:APP3e code library

echoservert_pre.c
echo_cnt.c
        Pre-threaded concurrent server

race.c
norace.c
        Threaded program with a race and its correct counterpart
rw1.c
        Solution to first readers-writers problem

sbuf.{c,h}
        Sbuf package used by pre-threaded server
