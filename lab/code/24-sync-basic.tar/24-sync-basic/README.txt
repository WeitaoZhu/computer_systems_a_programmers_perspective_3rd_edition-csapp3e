Support files for the first synchronization lecture

Makefile
        "make clean; make" to compile everything

badcnt.{c,s}
        C assembly code for the badcnt example

csapp.{c,h}
        CS:APP3e code library

goodcnt.c
        Uses semaphore mutexes to fix race in badcnt

sharing.c
        Example program for illustrating how variables are shared by threads
