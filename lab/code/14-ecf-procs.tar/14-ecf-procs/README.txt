Examples of Linux process control from lecture

FILES

Makefile
        "make clean; make" to compile everything

csapp.{c,h} 
        Various functions for the CS:APP3e book

fork.c 
        Simple example of fork

forks.c
        Multiple examples of Linux process control
        Usage: ./forks <n>



        

        
