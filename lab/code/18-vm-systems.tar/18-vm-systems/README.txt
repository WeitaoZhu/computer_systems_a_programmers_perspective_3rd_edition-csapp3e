Files for the VM lecture

Makefile
        "make clean; make" to compile everything

badrefs.c
        Generates bad references that elicit signals

csapp.{c,h}
        CS:APP functions

mmapcopy.c
        Using mmap to copy a file to stdout
