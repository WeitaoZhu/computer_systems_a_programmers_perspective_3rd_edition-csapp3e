
Makefile
        "make clean; make" to compile


mallocex.c
        Malloc usage example

