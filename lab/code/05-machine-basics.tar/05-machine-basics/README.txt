Extensions:
	.64s: x86-64 assembly code
	.64d: x86-64 disassembly

FILES

arith.c
arith.64s
	Sample arithmetic code

sum.c
sum.64s
sum.64d
	Demonstration of memory referencing and procedure calls

sum64
	Compiled x86-64 executable of sum.c

swap.c
swap.64s
	Demonstration of memory referencing

