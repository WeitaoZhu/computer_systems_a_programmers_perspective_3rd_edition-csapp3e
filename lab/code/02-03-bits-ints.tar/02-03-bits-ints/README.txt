show-bytes.c
        Demonstrates byte respresentations of different data types

show-bytes.{32,64}
        32- and 64-byte versions of show-bytes.c

sb64-15213.txt
        Output of ./show-bytes64 15213


